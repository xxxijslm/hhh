import Dog, {Animal,displayDate} from "./library2.js"

let obj = new Dog();
obj.makeSound();
displayDate();
// obj.weight = 10;
console.log(obj.weight, obj.location);