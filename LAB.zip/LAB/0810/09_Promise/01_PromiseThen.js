function longTimeWork(workFine = true, errorMessage = "test") {
    return new Promise( (resolve, reject) => {                       //把要做的很久，可能不會成功的工作放在promise物件裡
        setTimeout( () => {
            (workFine) ? resolve(200) : reject(errorMessage);
        }, 1000);
    })
}

function usingLongTimeWork() {
    longTimeWork(true, "test")  // try true/false
    .then(function (e) {        //承諾方法的物件then方法和catch方法
        console.log("success");
        console.log(e);
    })
    .catch(function (e) {
        console.log(e);
    })
}

usingLongTimeWork();
